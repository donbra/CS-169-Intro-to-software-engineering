class Movie < ApplicationRecord

    attr_accessor :ratings_to_show
  
    def initialize(attributes = {})
      super(attributes)
      @ratings_to_show = ['G', 'PG', 'PG-13', 'R']
    end
  
    def self.add_rating_to_show(rating_list)
      if rating_list.present?
        ratings_to_show = rating_list
      end
    end
  
    def self.all_ratings
      return ['G', 'PG', 'PG-13', 'R']
    end
  
    def self.with_ratings(rating_list)
      if rating_list.present?
        return Movie.where(rating: rating_list)
      else
        return Movie.all
      end
    end
  
    def self.sorting(sort_type)
      order(sort_type)
    end
end
  