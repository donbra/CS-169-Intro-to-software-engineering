Feature: display list of movies sorted by different criteria

  As an avid moviegoer
  So that I can quickly browse movies based on my preferences
  I want to see movies sorted by title or release date

Background: movies have been added to database

  Given the following movies exist:
  | title                   | rating | release_date |
  | Aladdin                 | G      | 25-Nov-1992  |
  | The Terminator          | R      | 26-Oct-1984  |
  | When Harry Met Sally    | R      | 21-Jul-1989  |
  | The Help                | PG-13  | 10-Aug-2011  |
  | Chocolat                | PG-13  | 5-Jan-2001   |
  | Amelie                  | R      | 25-Apr-2001  |
  | 2001: A Space Odyssey   | G      | 6-Apr-1968   |
  | The Incredibles         | PG     | 5-Nov-2004   |
  | Raiders of the Lost Ark | PG     | 12-Jun-1981  |
  | Chicken Run             | G      | 21-Jun-2000  |

  And I am on the RottenPotatoes home page
  Then 10 seed movies should exist

Scenario: sort movies alphabetically
  When I follow "Title"
  # your steps here
  And I check the "PG" checkbox
  And I check the "R" checkbox
  And I uncheck the "PG-13" checkbox
  And I uncheck the "G" checkbox
  And I press "Refresh"
  Then I should see "Raiders of the Lost Ark" before "When Harry Met Sally"
  Then I should see "Amelie" before "The Terminator"
  Then I should not see "A Space Odyssey"

Scenario: sort movies in increasing order of release date
  When I follow "Release Date"
  # your steps here
  And I uncheck the "PG" checkbox
  And I uncheck the "R" checkbox
  And I check the "PG-13" checkbox
  And I check the "G" checkbox
  And I press "Refresh"
  Then I should see "A Space Odyssey" before "Chicken Run"
  Then I should see "Chocolat" before "The Help"
  Then I should not see "Raiders of the Lost Ark"
  Then I should not see "The Incredibles"

