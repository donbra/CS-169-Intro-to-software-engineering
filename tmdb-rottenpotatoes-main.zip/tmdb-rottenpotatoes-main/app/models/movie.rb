
class Movie < ApplicationRecord

  API_KEY = '9748616caef3d509a8b18e40953353dd'

  def self.all_ratings
    %w[G PG PG-13 R]
  end

  def self.find_in_tmdb(search_params = {}, api_key = API_KEY)
    if search_params.nil? || search_params[:title].blank?
      return []
    end
    url = "https://api.themoviedb.org/3/search/movie?"
    construction = Faraday.new(url: url)
    given_response = construction.get do |req|
      req.params['api_key'] = API_KEY
      req.params['query'] = search_params[:title]
      req.params['year'] = search_params[:release_year] if search_params[:release_year].present?
      req.params['language'] = search_params[:language] if search_params[:language].present?
    end
    movies = JSON.parse(given_response.body)
    movies['results'].map do |movie| 
    {
      title: movie['title'],
      tmdb_id: movie['id'],
      rating: 'R',
      overview: movie['overview'],
      release_date: movie['release_date']
    }
    end
  end

  def self.with_ratings(ratings, sort_by)
    if ratings.nil?
      all.order sort_by
    else
      where(rating: ratings.map(&:upcase)).order sort_by
    end
  end
end
