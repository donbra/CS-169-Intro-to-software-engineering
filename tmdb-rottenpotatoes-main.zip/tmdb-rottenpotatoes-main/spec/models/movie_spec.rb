require 'rails_helper'

RSpec.describe Movie, type: :model do
  describe '.find_in_tmdb' do
    it 'calls TMDb with valid API key' do
      Movie.find_in_tmdb({ title: "hacker", language: "en" })
    end
  end
end